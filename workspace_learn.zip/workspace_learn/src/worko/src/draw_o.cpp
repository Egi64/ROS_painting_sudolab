#include<ros/ros.h>
#include<geometry_msgs/Twist.h>

int main(int argc,char **argv){

    ros::init(argc,argv,"draw_o");

    ros::NodeHandle n;

    ros::Publisher turtle_vel_o = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",10);

    ros::Rate loop_rate(2);
    
    int count=1;
    double PI=3.1415926535897932;
    while(ros::ok()){
        loop_rate.sleep();

        geometry_msgs::Twist vel_msg;
        
        if(count==1||count==2){
            vel_msg.linear.x=2*PI;
            vel_msg.angular.z=2*PI;
        }
        if(count>=3){
            vel_msg.linear.x=0;
            vel_msg.angular.z=0;
        }
        count++;
        
        turtle_vel_o.publish(vel_msg);
    }
    return 0;
}
