#include<ros/ros.h>
#include<geometry_msgs/Twist.h>

int main(int argc,char **argv)
{
    ros::init(argc,argv,"draw_a");

    ros::NodeHandle n;

    ros::Publisher turtle_vel_a = n.advertise<geometry_msgs::Twist>("/turtle1/cmd_vel",10);

    ros::Rate loop_rate(2);
    
    int count = 0;
    double PI=3.1415926535897932;
    while(ros::ok()){
        loop_rate.sleep();
        
        geometry_msgs::Twist vel_msg;
        
        count++;
        if(count==1){
            vel_msg.linear.x=0;
            vel_msg.angular.z=2*PI;
        }
        if(count==2){
            vel_msg.linear.x=2*PI;
            vel_msg.angular.z=2*PI;
        }
        if(count==3){
            vel_msg.linear.x=0;
            vel_msg.angular.z=PI;
        }    
        if(count==4){
            vel_msg.linear.x=4;
            vel_msg.angular.z=0;
        }      
        if(count==5){
            vel_msg.linear.x=PI;
            vel_msg.angular.z=PI;
        }
        if(count>=6){
            vel_msg.linear.x=0;
            vel_msg.angular.z=0;
        }
        
        turtle_vel_a.publish(vel_msg);
    }
    return 0;

}
